#byte portc = 0x07

#define status 0x03
#define rp0 0x05

int count = 0;
int f = 0;

void footer();
